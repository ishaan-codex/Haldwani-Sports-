
const observer=new IntersectionObserver(entries=>{
entries.forEach(entry=>{
if(entry.isIntersecting) entry.target.classList.add('show');
});
});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

document.querySelectorAll('.counter').forEach(counter=>{
const target=+counter.dataset.target;
let count=0;
const step=Math.ceil(target/120);
const update=()=>{
count+=step;
if(count>=target){counter.innerText=target+'+';return;}
counter.innerText=count;
requestAnimationFrame(update);
};
update();
});
